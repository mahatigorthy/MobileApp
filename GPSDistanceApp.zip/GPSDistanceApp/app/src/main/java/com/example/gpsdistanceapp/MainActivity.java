package com.example.gpsdistanceapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    LocationManager lm;
    Context context;
    double latitude, longitude;
    double sumDistances = 0;
    TextView textView1, textView2, textView3, textView4;
    Location lastLocation = null;
    List<Address> matches = null;
    LocationListener locationListenerGPS;
    ArrayList<Location> locationsArrayList;
    ArrayList<Double> distancesArrayList;
    ArrayList<String> addressesArrayList;
    List<Long> times;
    String addressLine, textViewText;
    long elapsedTime;
    long timesArray[];

    //ON ROTATION SAVING VALUES
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        lm.removeUpdates(locationListenerGPS);
        outState.putDouble("val", sumDistances);
        outState.putStringArrayList("locationAddresses", addressesArrayList);
        outState.putParcelableArrayList("list", locationsArrayList);
        outState.putString("textView4Text", textViewText);
        outState.putLongArray("times", timesArray);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //INITIALIZE VARIABLES
        locationsArrayList = new ArrayList<Location>();
        distancesArrayList = new ArrayList<Double>();
        addressesArrayList = new ArrayList<String>();
        times = new ArrayList<Long>();
        textView1 = findViewById(R.id.textView1); //long and lat
        textView2 = findViewById(R.id.textView2); //address
        textView3 = findViewById(R.id.textView3); //distance to
        textView4 = findViewById(R.id.textView4); //list of times


        //ON ROTATION SAVING VALUES
        if(savedInstanceState != null)
        {
            //restores sumDistances
            sumDistances = savedInstanceState.getDouble("val");
            textView3.setText("total distance traveled: "+sumDistances+" meters");
            Log.d("hi", String.valueOf(sumDistances));

            //restores array list of locations
            locationsArrayList = savedInstanceState.getParcelableArrayList("list");
            textView1.setText("latitude: " + locationsArrayList.get(locationsArrayList.size()-1).getLatitude() + "\nlongitude: " + locationsArrayList.get(locationsArrayList.size()-1).getLongitude());

            //restores array list of addresses
            addressesArrayList = savedInstanceState.getStringArrayList("locationAddresses");
            textView2.setText("current address:\n" + addressesArrayList.get(0));

            //restores array list of times
            timesArray = savedInstanceState.getLongArray("times");
            times.clear();
            //convert long to Long
            Long[] objLong = new Long[timesArray.length];
            for(int index = 0; index < objLong.length; index++)
            {
                objLong[index] = timesArray[index];
            }
            Collections.addAll(times, objLong);

            //sets the text of the textView4
            textViewText = savedInstanceState.getString("textView4Text");
            textView4.setText(textViewText);

            //restores lastLocation
            lastLocation = locationsArrayList.get(locationsArrayList.size()-1);
        }

        //LOCATION MANAGER
        context = this;
        lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        //PERMISSIONS
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.INTERNET}, 5622);
        }

        //ON LOCATION CHANGED
        Geocoder geoCoder = new Geocoder(getApplicationContext(), Locale.US);
        locationListenerGPS = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                //LAT AND LON
                if(lastLocation == null) {
                    Log.d("thread", "im in the process of sleeping!");
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Log.d("thread", "im done sleeping!");
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                } else {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                }
                textView1.setText("latitude: " + latitude + "\nlongitude: " + longitude);
                locationsArrayList.add(location);

                //ADDRESS
                try {
                    matches = geoCoder.getFromLocation(latitude, longitude, 1);

                    if (null != matches && matches.size() > 0) {
                        addressLine = matches.get(0).getAddressLine(0);
                        textView2.setText("current address:\n" + addressLine);
                        if (addressesArrayList == null || addressesArrayList.size() == 0) { //if its the first time
                            addressesArrayList.add(addressLine);
                            times.add(System.currentTimeMillis());
                        }
                        else {
                            if (!addressesArrayList.get(addressesArrayList.size() - 1).contains(addressLine)) { //if address before is the same as after
                                addressesArrayList.add(matches.get(0).getAddressLine(0));

                                //CALCULATE ELAPSED TIME
                                times.add(System.currentTimeMillis());
                                elapsedTime = times.get(times.size()-1) - times.get(times.size() - 2);
                                elapsedTime = (elapsedTime / 1000); //converts to seconds
                                textView4.setText("time from " + addressesArrayList.get(addressesArrayList.size() - 2) + " to " + addressesArrayList.get(addressesArrayList.size() - 1) + " is " + elapsedTime + " seconds\n\n");
                                textViewText = (String) textView4.getText();
                                timesArray = times.stream().mapToLong(i -> i).toArray();
                            }
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

                //DISTANCE TO
                if (lastLocation == null) {
                    lastLocation = location;
                }
                distancesArrayList.add((double) location.distanceTo(lastLocation));
                sumDistances += location.distanceTo(lastLocation);
                lastLocation = location;
                textView3.setText("total distance traveled: "+sumDistances+" meters");
            }

            @Override
            public void onProviderEnabled(@NonNull String provider) { }

            @Override
            public void onProviderDisabled(@NonNull String provider) { }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) { }
        };

        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 30, 0, locationListenerGPS);
    }
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

}