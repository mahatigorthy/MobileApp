package com.example.layoutorientationproject;

import android.os.Parcel;
import android.os.Parcelable;

public class OneDirectionAlbums implements Parcelable {

    int image;
    String name;
    String songs;
    String releaseDate;

    public OneDirectionAlbums(String name, String songs, int image, String releaseDate)
    {
        this.name = name;
        this.songs = songs;
        this.image = image;
        this.releaseDate = releaseDate;
    }

    private OneDirectionAlbums(Parcel in) {
        name = in.readString();
        songs = in.readString();
        image = in.readInt();
        releaseDate = in.readString();
    }

    public int describeContents() {
        return 0;
    }

    public String getName()
    {
        return name;
    }

    public String getSongs()
    {
        return songs;
    }

    public int getImage()
    {
        return image;
    }

    public String getReleaseDate()
    {
        return releaseDate;
    }


    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(songs);
        parcel.writeInt(image);
        parcel.writeString(releaseDate);
    }

    public static final Parcelable.Creator<OneDirectionAlbums> CREATOR = new Parcelable.Creator<OneDirectionAlbums>() {
        public OneDirectionAlbums createFromParcel(Parcel in) {
            return new OneDirectionAlbums(in);
        }

        public OneDirectionAlbums[] newArray(int size) {
            return new OneDirectionAlbums[size];
        }
    };
}
