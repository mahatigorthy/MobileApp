package com.example.layoutorientationproject;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<OneDirectionAlbums> {
    List<OneDirectionAlbums> list;
    Context context;
    int xmlResource;

    public CustomAdapter(Context context, int resource, List<OneDirectionAlbums> objects) {
        super(context, resource, objects);
        xmlResource = resource;
        list = objects;
        this.context = context;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        View adapterLayout = layoutInflater.inflate(xmlResource, null);

        TextView name = adapterLayout.findViewById(R.id.textView1);
        TextView songs = adapterLayout.findViewById(R.id.textView2);
        ImageView image = adapterLayout.findViewById(R.id.imageView);
        Button remove = adapterLayout.findViewById(R.id.button1);
        remove.setText("Remove");
        remove.setTextSize(10);

        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                list.remove(position);
                notifyDataSetChanged();
            }
        });

        name.setText(list.get(position).getName());
        songs.setText(list.get(position).getSongs());
        songs.setTextSize(10);
        image.setImageResource(list.get(position).getImage());
        return adapterLayout;


    }
}
