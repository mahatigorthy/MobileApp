//put my favorite songs from each album
package com.example.layoutorientationproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<OneDirectionAlbums> albumsArrayList;
    TextView textView;
    int variable;

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putParcelableArrayList("key", albumsArrayList);
        outState.putInt("variableKey", variable);
        super.onSaveInstanceState(outState);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listView = findViewById(R.id.list_id);
        textView = findViewById(R.id.textView3);

        if(savedInstanceState == null || !savedInstanceState.containsKey("key"))
        {
            albumsArrayList = new ArrayList<OneDirectionAlbums>();
            OneDirectionAlbums upAllNight = new OneDirectionAlbums("Up All Night", "Up All Night\nOne Thing\nGotta Be You", R.drawable.upallnight, "2011");
            OneDirectionAlbums takeMeHome = new OneDirectionAlbums("Take Me Home", "Still the One\nNobody Compares\nLast First Kiss", R.drawable.takemehome, "2012");
            OneDirectionAlbums midnightMemories = new OneDirectionAlbums("Midnight Memories", "Story of My Life\nDiana\nThrough the Dark", R.drawable.midnightmemories, "2013");
            OneDirectionAlbums four = new OneDirectionAlbums("Four", "Fool's Gold\nGirl Almighty\nSteal My Girl", R.drawable.four, "2014");
            OneDirectionAlbums madeInTheAM = new OneDirectionAlbums("Made In The AM", "Olivia\nEnd of the Day\nWhat a Feeling", R.drawable.madeintheam, "2015");

            albumsArrayList.add(upAllNight);
            albumsArrayList.add(takeMeHome);
            albumsArrayList.add(midnightMemories);
            albumsArrayList.add(four);
            albumsArrayList.add(madeInTheAM);
        }
        else
        {
            albumsArrayList = savedInstanceState.getParcelableArrayList("key");
        }

        if(savedInstanceState != null)
        {
            variable = savedInstanceState.getInt("variableKey");
            if(variable < albumsArrayList.size()) {
                Log.d("variableIf", String.valueOf(variable));
                listView.setSelection(variable);
                textView.setText("Release Date: " + albumsArrayList.get(variable).getReleaseDate());
            }
        }

        listView.setItemsCanFocus(false);
        listView.setFocusable(false);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(savedInstanceState == null)
                {
                    variable = i;
                    listView.setSelection(variable);
                    textView.setText("Release Date: "+albumsArrayList.get(variable).getReleaseDate());
                }
/*
                listView.setSelection(variable);
                Log.d("variableSelection", String.valueOf(variable));
                textView.setText("Release Date: "+albumsArrayList.get(variable).getReleaseDate());
                */
            }
        });


        CustomAdapter adapter = new CustomAdapter(this, R.layout.adapter_layout, albumsArrayList);
        listView.setAdapter(adapter);


    }



}
