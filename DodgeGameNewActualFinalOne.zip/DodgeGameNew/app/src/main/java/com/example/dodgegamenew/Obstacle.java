package com.example.dodgegamenew;

import android.graphics.Bitmap;


public class Obstacle {

    private Bitmap obstacle;
    private int incrementVal;

    public Obstacle(Bitmap obstacle, int incrementVal){
        this.obstacle = obstacle;
        this.incrementVal = incrementVal;

    }

    public Bitmap getObstacle() {
        return obstacle;
    }


    public int getIncrementVal() {
        return incrementVal;
    }

    public void setIncrement(int increment) {
        this.incrementVal = increment;
    }


}
