package com.example.dodgegamenew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {

    static GameSurface gameSurface;
    static MediaPlayer mediaPlayer, mediaPlayer2;
    static Canvas canvas;
    static AtomicInteger si = new AtomicInteger(60);;
    static int kVal;
    static int score;
    static TimerTask t;
    static Timer timer;
    static int rand = (int)(Math.random()*50+1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        gameSurface = new GameSurface(this);
        setContentView(gameSurface);
    }

    @Override
    protected void onResume() {
        super.onResume();
        gameSurface.resume();
        mediaPlayer  = MediaPlayer.create(MainActivity.this,R.raw.readytorun);
    }

    @Override
    protected void onStop() {
        super.onStop();
        //Demo when rotating
        mediaPlayer.reset();
        mediaPlayer.release();// good to release when done with activity
        mediaPlayer = null;

    }

    @Override
    protected void onPause() {
        super.onPause();
        gameSurface.pause();

    }

    public class GameSurface extends SurfaceView implements Runnable, SensorEventListener{

        Thread gameThread;
        SurfaceHolder holder;
        volatile boolean running = false;
        Bitmap gameChar, background;
        int ballX = 0;
        Paint paintProperty;
        int screenWidth;
        int screenHeight;
        float x, y, z;
        ArrayList<Obstacle> obstacles = new ArrayList<Obstacle>();

        public GameSurface(Context context){
            super(context);

            holder = getHolder();
            gameChar = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.normal), 350, 350, false);
            background = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.roadnew), 1150, 1950, false);

            Display screenDisplay = getWindowManager().getDefaultDisplay();
            Point sizeOfScreen = new Point();
            screenDisplay.getSize(sizeOfScreen);

            screenWidth = sizeOfScreen.x;
            screenHeight = sizeOfScreen.y;

            paintProperty = new Paint();

            mediaPlayer = MediaPlayer.create(getContext(), R.raw.readytorun);
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mediaPlayer.start();
                }
            });

            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.release();

                }
            });

            SensorManager sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            Sensor accelerometerSensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sm.registerListener((SensorEventListener) this, accelerometerSensor, sm.SENSOR_DELAY_NORMAL);

            timer = new Timer();
            t = new TimerTask() {
                @Override
                public void run() {
                    if (si.get() > 0) {
                        si.getAndDecrement();
                    } else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                timer.cancel();
                                endGame();
                            }
                        });

                    }
                }
            };


        }


        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            x = sensorEvent.values[0];
            y = sensorEvent.values[1];
            z = sensorEvent.values[2];
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }


        @Override
        public void run() {
            timer.scheduleAtFixedRate(t, 0, 1000);
            Log.d("scheduling timer", "timer");

            int flip = 1;
            while(running) {
                if(holder.getSurface().isValid() == false)
                {
                    continue;
                }
                canvas = holder.lockCanvas();
                drawCanvas(canvas);
                obstaclesUpdate(canvas);
                obstacleCreater(canvas);
                holder.unlockCanvasAndPost(canvas);

                if (x > 0 && x < 10) {
                    flip = -1;
                } else if (x > 10) {
                    flip = -4;
                } else if(x < 0 && x > -4)
                {
                    flip = 1;
                } else {
                    flip = 4;
                }

                if (ballX == (screenWidth)/2 - gameChar.getWidth()/2)
                {
                    flip = -1;
                }
                if (ballX == -1 * (screenWidth)/2 + gameChar.getWidth()/2) {
                    flip = 1;
                }
                ballX += flip;

            }
        }

        public void resume() {
            running = true;
            gameThread = new Thread(this);
            gameThread.start();

            mediaPlayer = MediaPlayer.create(getContext(), R.raw.readytorun);
        }

        public void pause() {
            running = false;
            while(true) {
                try {
                    gameThread.join();
                } catch (InterruptedException e) {

                }
            }

        }

        public void obstacleCreater(Canvas canvas) {
            Log.d("size", obstacles.size()+" ");
            if(obstacles.size()<1)
            {
                int randomNum = (int) (Math.random() * 50);
                if (randomNum == 1) {
                    Log.d("im making an obstacle", "obstacle");
                    Obstacle obstacle1 = new Obstacle((Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.policenew), 300, 300, false)), 0);
                    obstacles.add(obstacle1);

                    //obstacles.add(Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.policenew), 300, 300, false));
                    //obstacles.get(obstacles.size() - 1).setHeight(screenHeight / 25);
                    //obstacles.get(obstacles.size() - 1).setWidth((int) (screenWidth / 1.3));
                    //canvas.drawRGB(0, 100, 30);
                    //canvas.drawBitmap(obstacles.get(obstacles.size() - 1), (screenWidth)/2, (screenHeight/2) - obstacles.get(obstacles.size() - 1).getHeight()/2 + 0, null);
                }

            }

        }

        public void obstaclesUpdate(Canvas canvas) {
            //canvas.drawBitmap(gameChar, (screenWidth / 2) - gameChar.getWidth() / 2 + ballX, screenHeight / 2 + 300, null);
            for (int i = 0; i < obstacles.size(); i++) {
                int val = (screenHeight / 8) - obstacles.get(i).getObstacle().getHeight() / 2 + obstacles.get(i).getIncrementVal();
                if(rand%2 == 0)
                {
                    if (val < (screenHeight / 2 + 300)) {
                        canvas.drawBitmap(obstacles.get(i).getObstacle(), (screenWidth) / 2 - 10, val, null);
                        obstacles.get(i).setIncrement(obstacles.get(i).getIncrementVal()+8);
                    } else {
                        isCollision(i);
                    }

                }
                else {
                    if (val < (screenHeight / 2 + 300)) {
                        canvas.drawBitmap(obstacles.get(i).getObstacle(), (screenWidth) / 8 - 10, val, null);
                        obstacles.get(i).setIncrement(obstacles.get(i).getIncrementVal()+8);
                    } else {
                        isCollision(i);
                    }

                }

            }
        }

        public void drawCanvas (Canvas canvas) {
            canvas.drawBitmap(background, 0, 0, null);
            canvas.drawBitmap(gameChar, (screenWidth / 2) - gameChar.getWidth() / 2 + ballX, screenHeight / 2 + 300, null);

            Paint paint = new Paint();
            paint.setColor(Color.RED);
            paint.setTextSize(50);
            canvas.drawText("time: "+si.get()+" sec", (screenWidth / 18), (screenHeight / 18), paint);
        }

        public void changeImage (Bitmap bitmap, int val){
            if(si.get() == (val+1)){
                gameChar = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.normal), 350, 350, false);
                canvas.drawBitmap(gameChar, (screenWidth / 2) - gameChar.getWidth() / 2 + ballX, screenHeight / 2 + 300, null);
            }

        }

        public boolean isCollisionDetected(Bitmap bitmap1, Bitmap bitmap2) {
            int x1 = (screenWidth/2)-(bitmap1.getWidth()/2);
            int y1 = (screenHeight/2)-(bitmap1.getHeight()/2);

            int x2 = (screenWidth/2)-(bitmap2.getWidth()/2);
            int y2 = (screenHeight/2)-(bitmap2.getHeight()/2);
            Log.d("X1", x1+" ");
            Log.d("y1", y1+" ");
            Log.d("x2", x2+" ");
            Log.d("y2", y2+" ");
            Rect bounds1 = new Rect(x1, y1, x1 + bitmap1.getWidth(), y1 + bitmap1.getHeight());
            Rect bounds2 = new Rect(x2, y2, x2 + bitmap2.getWidth(), y2 + bitmap2.getHeight());

            if (Rect.intersects(bounds1, bounds2)) {
                Rect collisionBounds = getCollisionBounds(bounds1, bounds2);
                for (int i = collisionBounds.left; i < collisionBounds.right; i++) {
                    for (int j = collisionBounds.top; j < collisionBounds.bottom; j++) {
                        int bitmap1Pixel = bitmap1.getPixel(i - x1, j - y1);
                        int bitmap2Pixel = bitmap2.getPixel(i - x2, j - y2);
                        if (isFilled(bitmap1Pixel) && isFilled(bitmap2Pixel)) {
                            return true;
                        }
                    }
                }
            }
            return false;

        }

        public Rect getCollisionBounds(Rect rect1, Rect rect2) {
            int left = (int) Math.max(rect1.left, rect2.left);
            int top = (int) Math.max(rect1.top, rect2.top);
            int right = (int) Math.min(rect1.right, rect2.right);
            int bottom = (int) Math.min(rect1.bottom, rect2.bottom);
            return new Rect(left, top, right, bottom);
        }

        public boolean isFilled(int pixel) {
            return pixel != Color.TRANSPARENT;
        }




        public void isCollision(int i) {
            //int gameCharHeight = gameChar.getBounds().left;
            /*int gameCharWidth = gameChar.getWidth();

            int obstacleHeight = obstacles.get(i).getObstacle().getHeight();
            int obstacleWidth = obstacles.get(i).getObstacle().getWidth();

            //Log.d("gameCharHeight", gameCharHeight+" ");
            Log.d("gameCharWidth", gameCharWidth+" ");
            Log.d("obstacleHeight", obstacleHeight+" ");
            Log.d("obstacleWidth", obstacleWidth+" ");

            //Log.d("if statement1", Math.abs(gameCharHeight-obstacleHeight)+" ");
            Log.d("if statement2", Math.abs(gameCharWidth-obstacleWidth)+" ");*/

            //if(Math.abs(gameCharHeight-obstacleHeight) < 55 && Math.abs(gameCharWidth-obstacleWidth) < 55)
            //if(gameChar.intersects())
            Log.d("weirdo", String.valueOf(isCollisionDetected(gameChar, obstacles.get(i).getObstacle())));
            if(isCollisionDetected(gameChar, obstacles.get(i).getObstacle()) == true)
            {
                mediaPlayer2 = MediaPlayer.create(getContext(), R.raw.oncollision);
                mediaPlayer2.start();
                int siVal = si.get();
                changeImage(gameChar, siVal);
                obstacles.remove(i);
                gameChar = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.dead), 350, 350, false);
                canvas.drawBitmap(gameChar, (screenWidth / 2) - gameChar.getWidth() / 2 + ballX, screenHeight / 2 + 300, null);

            } else {
                //gameChar = BitmapFactory.decodeResource(getResources(), R.drawable.dead);
                //obstacles.get(i).getObstacle() = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.dead));
                score++;
                obstacles.remove(i);
                rand = (int)(Math.random()*50+1);
            }
        }
    } // GameSurface

    public void endGame(){
        Paint paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setTextSize(90);
        //canvas.drawText("final score: "+score, (screenWidth / 2), (screenHeight / 2), paint);*/
        Intent myIntent = new Intent(MainActivity.this, SecondActivity.class);
        myIntent.putExtra("score", score);
        startActivity(myIntent);

        //canvas.drawText("final score: "+score, (screenWidth / 2), (screenHeight / 2), paint);

    }

} // Main Activity