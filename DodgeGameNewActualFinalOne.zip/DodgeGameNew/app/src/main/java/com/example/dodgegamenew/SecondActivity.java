package com.example.dodgegamenew;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textView = findViewById(R.id.textView);

        Bundle extra = getIntent().getExtras();
        String chosen = extra.getString("score");
        Log.d("chosen", chosen);
        textView.setText(chosen);

    }
}